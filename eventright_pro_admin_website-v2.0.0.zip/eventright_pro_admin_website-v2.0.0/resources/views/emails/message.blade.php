<p>Email From : {{ $data['email'] }}</p>
<p>Name : {{ $data['name'] }}</p>
<p>
    Subject : {{ $data['subject']}}
</p>

<p>
    Message : {{ $data['msg'] }}
</p>
